import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ActionListWindow extends JFrame {

	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ActionListWindow frame = new ActionListWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ActionListWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Please Select an Action");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 22));
		lblNewLabel.setBounds(27, 39, 350, 15);
		contentPane.add(lblNewLabel);
		
		JButton btnAdmission = new JButton("Admission");
		btnAdmission.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdmissionWindow aw = new AdmissionWindow();
				aw.setVisible(true);
				
			}
		});
		btnAdmission.setBounds(142, 100, 173, 25);
		contentPane.add(btnAdmission);
		
		JButton btnFeePayment = new JButton("Fee Payment");
		btnFeePayment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FeePaymentWindow fpw = new FeePaymentWindow();
				fpw.setVisible(true);
			}
		});
		btnFeePayment.setBounds(142, 149, 173, 25);
		contentPane.add(btnFeePayment);
		
		JButton btnViewRecord = new JButton("View Record");
		btnViewRecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewRecordsWindow vrw = new ViewRecordsWindow();
				vrw.setVisible(true);
			}
		});
		btnViewRecord.setBounds(142, 195, 173, 25);
		contentPane.add(btnViewRecord);
		
		JButton btnShowDefaulters = new JButton("Show Defaulters");
		btnShowDefaulters.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
	}

}
